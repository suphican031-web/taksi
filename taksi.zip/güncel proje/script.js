// =========================================
// LAPTA TAKSİ – JavaScript
// =========================================

// --- Navbar scroll effect ---
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 50) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
});

// --- Hamburger menu ---
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('navLinks');

hamburger.addEventListener('click', () => {
  hamburger.classList.toggle('open');
  navLinks.classList.toggle('open');
});

// Close menu when a link is clicked
navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    hamburger.classList.remove('open');
    navLinks.classList.remove('open');
  });
});

// --- Smooth scroll for anchor links ---
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const offset = 80;
      const top = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});

// --- Scroll reveal animation ---
const revealElements = document.querySelectorAll('[data-reveal]');
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry, index) => {
    if (entry.isIntersecting) {
      // Staggered delay based on position in parent
      const siblings = Array.from(entry.target.parentElement.children);
      const idx = siblings.indexOf(entry.target);
      setTimeout(() => {
        entry.target.classList.add('revealed');
      }, idx * 100);
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });

revealElements.forEach(el => revealObserver.observe(el));

// --- Car photo switcher ---
function changeCarPhoto(src, thumbEl) {
  const mainPhoto = document.getElementById('activeCarPhoto');
  if (mainPhoto) {
    mainPhoto.style.opacity = '0';
    mainPhoto.style.transform = 'scale(0.98)';
    setTimeout(() => {
      mainPhoto.src = src;
      mainPhoto.style.opacity = '1';
      mainPhoto.style.transform = 'scale(1)';
    }, 250);
  }
  document.querySelectorAll('.car-thumb').forEach(t => t.classList.remove('active'));
  if (thumbEl) thumbEl.classList.add('active');
}

// Add transition to car photo
const activePhoto = document.getElementById('activeCarPhoto');
if (activePhoto) {
  activePhoto.style.transition = 'opacity 0.25s ease, transform 0.25s ease';
}

// --- Number counter animation ---
function animateCounter(el, target, duration = 2000) {
  let start = 0;
  const increment = target / (duration / 16);
  const timer = setInterval(() => {
    start += increment;
    if (start >= target) {
      el.textContent = target.toLocaleString('tr-TR');
      clearInterval(timer);
    } else {
      el.textContent = Math.floor(start).toLocaleString('tr-TR');
    }
  }, 16);
}

// Trigger counters when stats section is visible
const statsBar = document.querySelector('.stats-bar');
if (statsBar) {
  const counterObserver = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting) {
      const statNums = document.querySelectorAll('.stat-number');
      statNums.forEach(el => {
        const text = el.textContent.trim();
        const num = parseInt(text.replace(/[^0-9]/g, ''));
        if (!isNaN(num) && num > 0 && !text.includes('★')) {
          animateCounter(el, num);
        }
      });
      counterObserver.disconnect();
    }
  }, { threshold: 0.5 });
  counterObserver.observe(statsBar);
}

// --- Active nav link on scroll ---
const sections = document.querySelectorAll('section[id]');
const navLinkEls = document.querySelectorAll('.nav-link');

window.addEventListener('scroll', () => {
  let current = '';
  sections.forEach(section => {
    const sectionTop = section.offsetTop - 100;
    if (window.scrollY >= sectionTop) {
      current = section.getAttribute('id');
    }
  });
  navLinkEls.forEach(link => {
    link.style.color = '';
    if (link.getAttribute('href') === '#' + current) {
      link.style.color = 'var(--gold)';
    }
  });
});

// --- Float call button hide on scroll up / show on scroll down ---
let lastScroll = 0;
const floatCall = document.querySelector('.float-call');
window.addEventListener('scroll', () => {
  const currentScroll = window.scrollY;
  if (floatCall) {
    if (currentScroll < 200) {
      floatCall.style.opacity = '0';
      floatCall.style.pointerEvents = 'none';
    } else {
      floatCall.style.opacity = '1';
      floatCall.style.pointerEvents = 'auto';
    }
  }
  lastScroll = currentScroll;
}, { passive: true });

// --- Parallax subtle effect on hero ---
const heroBgMedia = document.querySelector('.hero-bg-video, .hero-bg-img');
window.addEventListener('scroll', () => {
  if (heroBgMedia && window.scrollY < window.innerHeight) {
    heroBgMedia.style.transform = `scale(1.04) translateY(${window.scrollY * 0.12}px)`;
  }
}, { passive: true });

console.log('%c🚖 Girne Taksi Website Loaded', 'color: #C9A84C; font-weight: bold; font-size: 16px;');

// =========================================
// ONE-TOUCH INSTANT LOCATION SYSTEM
// =========================================
const TAXI_WHATSAPP_NUMBER = '905338899053';

// DOM Elements
const heroLocationBtn = document.getElementById('heroLocationBtn');
const floatLocationBtn = document.getElementById('floatLocationBtn');

const locationToast = document.getElementById('locationToast');
const toastTitle = document.getElementById('toastTitle');
const toastMsg = document.getElementById('toastMsg');
const toastSpinner = document.getElementById('toastSpinner');
const toastIcon = document.getElementById('toastIcon');

function showToast(title, msg, isError = false, isLoading = false) {
  if (!locationToast) return;
  toastTitle.textContent = title;
  toastMsg.textContent = msg;
  
  if (isLoading) {
    toastSpinner.style.display = 'block';
    toastIcon.style.display = 'none';
  } else {
    toastSpinner.style.display = 'none';
    toastIcon.style.display = 'block';
    toastIcon.textContent = isError ? '⚠️' : '✅';
  }
  
  locationToast.classList.add('show');
  
  if (!isLoading) {
    setTimeout(() => {
      locationToast.classList.remove('show');
    }, 3500);
  }
}

function hideToast() {
  if (locationToast) locationToast.classList.remove('show');
}

// Function to fetch GPS and open WhatsApp directly
function sendInstantLocation() {
  showToast('Konumunuz Alınıyor...', 'GPS koordinatlarınız belirleniyor, lütfen bekleyin...', false, true);

  if (!navigator.geolocation) {
    handleLocationResult(null);
    return;
  }

  const geoOptions = {
    enableHighAccuracy: true,
    timeout: 10000,
    maximumAge: 0
  };

  navigator.geolocation.getCurrentPosition(
    (position) => {
      const { latitude, longitude } = position.coords;
      const mapsUrl = `https://maps.google.com/?q=${latitude.toFixed(6)},${longitude.toFixed(6)}`;
      handleLocationResult(mapsUrl);
    },
    (error) => {
      console.warn('Geolocation error:', error);
      showToast('Konum İzni Alınamadı', 'WhatsApp açılıyor, konumunuzu sohbetten iletebilirsiniz.', true, false);
      setTimeout(() => {
        handleLocationResult(null);
      }, 900);
    },
    geoOptions
  );
}

function handleLocationResult(mapsUrl) {
  hideToast();

  const message = buildLocalizedLocationMessage(mapsUrl);
  const waUrl = `https://wa.me/${TAXI_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;

  const toastTitleText = currentLanguage === 'en' ? 'Opening WhatsApp...' : (currentLanguage === 'ru' ? 'Открытие WhatsApp...' : 'WhatsApp Açılıyor...');
  const toastDescText = currentLanguage === 'en' ? 'Sending live location...' : (currentLanguage === 'ru' ? 'Отправка геолокации...' : 'Canlı konumunuz iletiliyor...');

  showToast(toastTitleText, toastDescText, false, false);
  
  setTimeout(() => {
    window.open(waUrl, '_blank');
  }, 350);
}

// Bind location buttons
if (heroLocationBtn) {
  heroLocationBtn.addEventListener('click', sendInstantLocation);
}
if (floatLocationBtn) {
  floatLocationBtn.addEventListener('click', sendInstantLocation);
}

// =========================================
// MULTI-LANGUAGE (i18n) SYSTEM (TR / EN / RU)
// =========================================
const translations = {
  tr: {
    nav_home: "Anasayfa",
    nav_services: "Hizmetler",
    nav_fleet: "Araçlarımız",
    nav_airport: "Uçuş Karşılama",
    nav_reviews: "Yorumlar",
    nav_contact: "İletişim",
    live_status: "CANLI DURUM: Girne & Lapta'da Aracımız Boşta • Varış: 5-8 Dk",
    hero_title: "Girne & Girne'nin<br><span class=\"hero-title-accent\">Premium Taksi</span> Hizmeti",
    hero_subtitle: "Mercedes E-Serisi ile konforlu, güvenli ve zamanında ulaşım.<br>Ercan Havalimanı • Şehirlerarası • VIP Transfer",
    flight_badge: "Ercan Havalimanı Transfer",
    flight_title: "VIP Terminal <span class=\"text-gold\">Karşılama & Uçuş Takibi</span>",
    flight_desc: "Uçuşunuz gecikse dahi sistemimiz uçuş numaranızı canlı takip eder. Mercedes E-Serisi aracımız terminal kapısında sizi bekler.",
    form_name: "Yolcu Adı Soyadı *",
    form_phone: "Telefon / WhatsApp *",
    form_flight_no: "Uçuş Numarası *",
    form_flight_time: "Tahmini İniş Tarihi & Saati",
    form_destination: "Gidilecek Otel / Adres (Girne, Lapta vb.) *",
    btn_flight_submit: "WhatsApp ile VIP Karşılama İste",
    reviews_title: "Yolcularımız <span class=\"text-gold\">Ne Diyor?</span>",
    reviews_desc: "Girne ve KKTC genelinde her gün yüzlerce mutlu yolcumuza 5 yıldızlı premium ulaşım deneyimi sunuyoruz.",
    reviews_google_count: "(180+ Doğrulanmış Google Yorumu)"
  },
  en: {
    nav_home: "Home",
    nav_services: "Services",
    nav_fleet: "Our Fleet",
    nav_airport: "Airport Pickup",
    nav_reviews: "Reviews",
    nav_contact: "Contact",
    live_status: "LIVE STATUS: Mercedes Available in Kyrenia & Lapta • ETA: 5-8 Mins",
    hero_title: "Kyrenia's Premier<br><span class=\"hero-title-accent\">VIP Mercedes Taxi</span> Service",
    hero_subtitle: "Comfortable, safe and punctual transport with Mercedes E-Class.<br>Ercan Airport • Intercity • VIP Transfer",
    flight_badge: "Ercan Airport Transfer",
    flight_title: "VIP Terminal <span class=\"text-gold\">Meet & Greet Service</span>",
    flight_desc: "Even if your flight is delayed, we track your flight number in real time. Our Mercedes awaits you right outside the arrivals gate.",
    form_name: "Passenger Full Name *",
    form_phone: "Phone / WhatsApp *",
    form_flight_no: "Flight Number (e.g. TK960) *",
    form_flight_time: "Expected Arrival Date & Time",
    form_destination: "Drop-off Hotel / Address (Kyrenia, Lapta etc.) *",
    btn_flight_submit: "Book VIP Airport Pickup on WhatsApp",
    reviews_title: "What Our <span class=\"text-gold\">Passengers Say</span>",
    reviews_desc: "Delivering 5-star premium travel experiences every day across Kyrenia and North Cyprus.",
    reviews_google_count: "(180+ Verified Google Reviews)"
  },
  ru: {
    nav_home: "Главная",
    nav_services: "Услуги",
    nav_fleet: "Наш автопарк",
    nav_airport: "Встреча в аэропорту",
    nav_reviews: "Отзывы",
    nav_contact: "Контакты",
    live_status: "СТАТУС: Автомобиль свободен в Кирении и Лапте • Подача: 5-8 Мин",
    hero_title: "Премиум Такси в Кирении<br><span class=\"hero-title-accent\">Mercedes VIP</span>",
    hero_subtitle: "Комфортные, безопасные и пунктуальные поездки на Mercedes E-Class.<br>Аэропорт Эрджан • Междугородние поездки • VIP трансфер",
    flight_badge: "Трансфер из Аэропорта Эрджан",
    flight_title: "VIP Встреча в терминале <span class=\"text-gold\">с отслеживанием рейса</span>",
    flight_desc: "Даже в случае задержки рейса мы отслеживаем его онлайн. Mercedes E-Class будет ожидать вас прямо у выхода из терминала.",
    form_name: "ФИО пассажира *",
    form_phone: "Телефон / WhatsApp *",
    form_flight_no: "Номер рейса (напр. TK960) *",
    form_flight_time: "Дата и время прибытия",
    form_destination: "Отель или адрес назначения (Кирения, Лапта и др.) *",
    btn_flight_submit: "Заказать VIP встречу в WhatsApp",
    reviews_title: "Отзывы наших <span class=\"text-gold\">пассажиров</span>",
    reviews_desc: "Предоставляем 5-звездочный сервис премиум-поездок по всей Кирении и Северному Кипру.",
    reviews_google_count: "(180+ подтвержденных отзывов Google)"
  }
};

let currentLanguage = localStorage.getItem('girne_taxi_lang') || 'tr';

function setLanguage(lang) {
  if (!translations[lang]) return;
  currentLanguage = lang;
  localStorage.setItem('girne_taxi_lang', lang);

  // Update button active state
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-lang') === lang);
  });

  // Update text elements with data-i18n
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (translations[lang][key]) {
      el.innerHTML = translations[lang][key];
    }
  });

  console.log(`Language set to: ${lang}`);
}

// Bind language switcher buttons
document.querySelectorAll('.lang-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const lang = btn.getAttribute('data-lang');
    setLanguage(lang);
  });
});

// Update location WhatsApp message to match current language
function buildLocalizedLocationMessage(mapsUrl) {
  if (currentLanguage === 'en') {
    let msg = `🚖 *KYRENIA TAXI - LIVE LOCATION REQUEST*\n`;
    msg += `━━━━━━━━━━━━━━━━━━\n`;
    if (mapsUrl) {
      msg += `📍 *My Live Location:*\n${mapsUrl}\n`;
    } else {
      msg += `📍 Please send a VIP taxi to my location (sharing live on WhatsApp).\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━\n`;
    msg += `Please dispatch a Mercedes taxi as soon as possible. Thank you!`;
    return msg;
  } else if (currentLanguage === 'ru') {
    let msg = `🚖 *ТАКСИ КИРЕНИЯ - ЗАПРОС ЛОКАЦИИ*\n`;
    msg += `━━━━━━━━━━━━━━━━━━\n`;
    if (mapsUrl) {
      msg += `📍 *Моя геолокация:*\n${mapsUrl}\n`;
    } else {
      msg += `📍 Пожалуйста, пришлите такси к моему местоположению.\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━\n`;
    msg += `Пожалуйста, отправьте автомобиль Mercedes как можно скорее. Спасибо!`;
    return msg;
  } else {
    let msg = `🚖 *GİRNE TAKSİ - ANLIK KONUM TALEBİ*\n`;
    msg += `━━━━━━━━━━━━━━━━━━\n`;
    if (mapsUrl) {
      msg += `📍 *Canlı Konumum:*\n${mapsUrl}\n`;
    } else {
      msg += `📍 Bulunduğum konuma acil taksi rica ediyorum.\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━\n`;
    msg += `Bulunduğum konuma lütfen acil taksi yönlendiriniz. Teşekkürler!`;
    return msg;
  }
}

// =========================================
// ERCAN AIRPORT FLIGHT BOOKING FORM
// =========================================
const flightBookingForm = document.getElementById('flightBookingForm');
if (flightBookingForm) {
  flightBookingForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const passengerName = document.getElementById('flightPassengerName').value.trim();
    const passengerPhone = document.getElementById('flightPassengerPhone').value.trim();
    const flightNo = document.getElementById('flightNumber').value.trim();
    const flightTime = document.getElementById('flightDateTime').value.trim();
    const destination = document.getElementById('flightDestination').value.trim();

    let flightMsg = `✈️ *GİRNE TAKSİ - ERCAN VIP KARŞILAMA REZERVASYONU*\n`;
    flightMsg += `━━━━━━━━━━━━━━━━━━\n`;
    flightMsg += `👤 *Yolcu:* ${passengerName}\n`;
    flightMsg += `📞 *Telefon:* ${passengerPhone}\n`;
    flightMsg += `🛫 *Uçuş No:* ${flightNo}\n`;
    if (flightTime) flightMsg += `🕒 *İniş Saati:* ${flightTime}\n`;
    flightMsg += `🏨 *Hedef:* ${destination}\n`;
    flightMsg += `━━━━━━━━━━━━━━━━━━\n`;
    flightMsg += `Lütfen terminal çıkışında Mercedes E-Serisi ile karşılayınız.`;

    const flightWaUrl = `https://wa.me/${TAXI_WHATSAPP_NUMBER}?text=${encodeURIComponent(flightMsg)}`;
    
    showToast('WhatsApp Açılıyor...', 'VIP uçuş karşılama talebiniz iletiliyor.', false, false);
    setTimeout(() => {
      window.open(flightWaUrl, '_blank');
    }, 400);
  });
}

// Initialize saved language
document.addEventListener('DOMContentLoaded', () => {
  if (currentLanguage !== 'tr') {
    setLanguage(currentLanguage);
  }
});


